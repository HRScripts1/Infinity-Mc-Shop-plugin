# HR Shop 26.2

A Paper plugin with a GUI shop and a built-in economy (no Vault dependency).

## Included
- `/shop` opens the category GUI; click a category to browse.
- In a category, left-click an item to buy one; right-click to sell one.
- Default categories: Ores, Blocks, Redstone, Enchanted Books.
- `/bal` shows your balance.
- `/baltop` shows the top 10 balances known to this server.
- OP-only `/hrshop edit` opens the editor.
- OP-only commands:
  - `/hrshop addsection <id> <display name>`
  - `/hrshop editsection <id> <new display name>`\n  - `/hrshop delsection <id>`
  - Hold an item, then `/hrshop additem <section> <buy> <sell>`
  - `/hrshop delitem <section> <material>`
  - `/hrshop price <section> <material> <buy> <sell>`
  - `/hrshop setmoney <player> <amount>`
- Set buy or sell price to `-1` to disable that transaction.

## Build with GitHub (Android-friendly)
1. Create a GitHub repository named `HR-Shop`.
2. Upload all files and folders from this project, keeping their paths.
3. Open **Actions** and enable GitHub Actions if prompted.
4. Run **Build HR Shop** (or push a commit to `main`).
5. Open the successful workflow run, then download the `HR-Shop-26.2` artifact. It contains `hr-shop-26.2.jar`.
6. Upload that JAR to your Paper server's `plugins` folder and restart.

## Build locally
Requires JDK 25 and Maven 3.9+:
```bash
mvn clean package
```
The JAR is created at `target/hr-shop-26.2.jar`.

## Version compatibility note
This project targets Minecraft/Paper `26.2`, using Paper API `26.2.build.135-stable` and Java 25. Paper 26.2 requires Java 25 or newer. The plugin's own version is also labelled `26.2`.

## Economy data
Balances are saved in `plugins/HRShop/balances.yml`; shop categories and prices are saved in `plugins/HRShop/shop.yml`. Back up these files before updating or reinstalling.
