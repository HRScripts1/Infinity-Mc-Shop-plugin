package com.hrscripts.hrshop;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class HRShopPlugin extends JavaPlugin implements Listener, CommandExecutor {
    private final Map<UUID, Double> balances = new HashMap<>();
    private final Map<String, ShopSection> sections = new LinkedHashMap<>();
    private File balanceFile, shopFile;
    private YamlConfiguration balanceData;
    private String currency;

    @Override public void onEnable() {
        saveDefaultConfig();
        currency = getConfig().getString("currency-symbol", "$");
        loadBalances();
        loadShop();
        for (String cmd : List.of("shop", "hrshop", "bal", "baltop"))
            Objects.requireNonNull(getCommand(cmd), "Missing command " + cmd).setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("HR Shop 26.2 enabled.");
    }
    @Override public void onDisable() { saveBalances(); saveShop(); }

    private void loadBalances() {
        balanceFile = new File(getDataFolder(), "balances.yml");
        balanceData = YamlConfiguration.loadConfiguration(balanceFile);
        ConfigurationSection sec = balanceData.getConfigurationSection("balances");
        if (sec != null) for (String id : sec.getKeys(false)) {
            try { balances.put(UUID.fromString(id), sec.getDouble(id)); } catch (IllegalArgumentException ignored) {}
        }
    }
    private void saveBalances() {
        if (balanceData == null) return;
        for (var e : balances.entrySet()) balanceData.set("balances." + e.getKey(), e.getValue());
        try { balanceData.save(balanceFile); } catch (IOException ex) { getLogger().severe("Could not save balances: " + ex.getMessage()); }
    }
    private double balance(UUID id) { return balances.computeIfAbsent(id, k -> getConfig().getDouble("starting-balance", 1000.0)); }
    private void setBalance(UUID id, double amount) { balances.put(id, Math.max(0, amount)); saveBalances(); }
    private void loadShop() {
        shopFile = new File(getDataFolder(), "shop.yml");
        if (!shopFile.exists()) saveResource("shop.yml", false);
        YamlConfiguration y = YamlConfiguration.loadConfiguration(shopFile);
        ConfigurationSection root = y.getConfigurationSection("sections");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) continue;
            ShopSection section = new ShopSection(id.toLowerCase(Locale.ROOT), s.getString("name", id), s.getString("icon", "CHEST"));
            ConfigurationSection items = s.getConfigurationSection("items");
            if (items != null) for (String key : items.getKeys(false)) {
                ConfigurationSection it = items.getConfigurationSection(key);
                if (it == null) continue;
                try {
                    Material m = Material.valueOf(it.getString("material", key).toUpperCase(Locale.ROOT));
                    section.items.put(m, new ShopItem(m, it.getDouble("buy", -1), it.getDouble("sell", -1)));
                } catch (IllegalArgumentException ex) { getLogger().warning("Unknown material: " + key); }
            }
            sections.put(section.id, section);
        }
    }
    private void saveShop() {
        YamlConfiguration y = new YamlConfiguration();
        for (ShopSection s : sections.values()) {
            String p = "sections." + s.id;
            y.set(p + ".name", s.name); y.set(p + ".icon", s.icon);
            for (ShopItem it : s.items.values()) {
                String ip = p + ".items." + it.material.name();
                y.set(ip + ".material", it.material.name()); y.set(ip + ".buy", it.buy); y.set(ip + ".sell", it.sell);
            }
        }
        try { y.save(shopFile); } catch (IOException ex) { getLogger().severe("Could not save shop: " + ex.getMessage()); }
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] a) {
        String cmd = command.getName().toLowerCase(Locale.ROOT);
        if (cmd.equals("shop")) {
            if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
            ShopSection s = a.length > 0 ? sections.get(a[0].toLowerCase(Locale.ROOT)) : null;
            if (s == null) openMain(p); else openSection(p, s);
            return true;
        }
        if (cmd.equals("bal")) {
            if (a.length == 0 && sender instanceof Player p) {
                sender.sendMessage(color("&aBalance: &f" + money(balance(p.getUniqueId())))); return true;
            }
            if (a.length == 1 && sender.hasPermission("hrshop.admin")) {
                OfflinePlayer target = Bukkit.getOfflinePlayer(a[0]);
                sender.sendMessage(color("&a" + target.getName() + "'s balance: &f" + money(balance(target.getUniqueId())))); return true;
            }
            sender.sendMessage(color("&eUsage: /bal" + (sender.hasPermission("hrshop.admin") ? " [player]" : ""))); return true;
        }
        if (cmd.equals("baltop")) { showTop(sender); return true; }
        if (!sender.hasPermission("hrshop.admin")) { sender.sendMessage(color("&cYou need operator permission.")); return true; }
        if (!(sender instanceof Player p)) { sender.sendMessage("Use this command in-game."); return true; }
        if (a.length == 0 || a[0].equalsIgnoreCase("edit")) { openEditor(p); return true; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "addsection" -> {
                if (a.length < 3) { p.sendMessage(color("&e/hrshop addsection <id> <display name>")); return true; }
                String id = a[1].toLowerCase(Locale.ROOT);
                if (sections.containsKey(id)) { p.sendMessage(color("&cSection already exists.")); return true; }
                sections.put(id, new ShopSection(id, String.join(" ", Arrays.copyOfRange(a, 2, a.length)), "CHEST"));
                saveShop(); p.sendMessage(color("&aSection added: " + id));
            }
            case "delsection" -> {
                if (a.length < 2) { p.sendMessage(color("&e/hrshop delsection <id>")); return true; }
                sections.remove(a[1].toLowerCase(Locale.ROOT)); saveShop(); p.sendMessage(color("&aSection deleted if it existed."));
            }
            case "editsection" -> {
                if (a.length < 3) { p.sendMessage(color("&e/hrshop editsection <id> <new display name>")); return true; }
                ShopSection section = sections.get(a[1].toLowerCase(Locale.ROOT));
                if (section == null) { p.sendMessage(color("&cSection not found.")); return true; }
                section.name = String.join(" ", Arrays.copyOfRange(a, 2, a.length));
                saveShop(); p.sendMessage(color("&aSection name updated."));
            }
            case "additem" -> {
                if (a.length != 4 || p.getInventory().getItemInMainHand().getType().isAir()) {
                    p.sendMessage(color("&eHold an item: /hrshop additem <section> <buy> <sell>")); return true;
                }
                ShopSection s = sections.get(a[1].toLowerCase(Locale.ROOT));
                if (s == null) { p.sendMessage(color("&cSection not found.")); return true; }
                try {
                    double buy = Double.parseDouble(a[2]), sell = Double.parseDouble(a[3]);
                    if (buy < -1 || sell < -1 || !Double.isFinite(buy) || !Double.isFinite(sell)) throw new NumberFormatException();
                    Material m = p.getInventory().getItemInMainHand().getType();
                    s.items.put(m, new ShopItem(m, buy, sell)); saveShop(); p.sendMessage(color("&aItem saved."));
                } catch (NumberFormatException ex) { p.sendMessage(color("&cPrices must be numbers; use -1 to disable a transaction.")); }
            }
            case "delitem" -> {
                if (a.length != 3) { p.sendMessage(color("&e/hrshop delitem <section> <material>")); return true; }
                ShopSection s = sections.get(a[1].toLowerCase(Locale.ROOT));
                if (s == null) { p.sendMessage(color("&cSection not found.")); return true; }
                try { s.items.remove(Material.valueOf(a[2].toUpperCase(Locale.ROOT))); saveShop(); p.sendMessage(color("&aItem deleted if it existed.")); }
                catch (IllegalArgumentException ex) { p.sendMessage(color("&cUnknown material.")); }
            }
            case "price" -> {
                if (a.length != 5) { p.sendMessage(color("&e/hrshop price <section> <material> <buy> <sell>")); return true; }
                ShopSection s = sections.get(a[1].toLowerCase(Locale.ROOT));
                if (s == null) { p.sendMessage(color("&cSection not found.")); return true; }
                try {
                    Material m = Material.valueOf(a[2].toUpperCase(Locale.ROOT));
                    double buy = Double.parseDouble(a[3]), sell = Double.parseDouble(a[4]);
                    if (buy < -1 || sell < -1 || !Double.isFinite(buy) || !Double.isFinite(sell)) throw new NumberFormatException();
                    s.items.put(m, new ShopItem(m, buy, sell)); saveShop(); p.sendMessage(color("&aPrices updated."));
                } catch (IllegalArgumentException ex) { p.sendMessage(color("&cInvalid material or price.")); }
            }
            case "setmoney" -> {
                if (a.length != 3) { p.sendMessage(color("&e/hrshop setmoney <player> <amount>")); return true; }
                try {
                    OfflinePlayer target = Bukkit.getOfflinePlayer(a[1]); double amount = Double.parseDouble(a[2]);
                    if (amount < 0 || !Double.isFinite(amount)) throw new NumberFormatException();
                    balances.put(target.getUniqueId(), amount); saveBalances(); p.sendMessage(color("&aBalance updated."));
                } catch (NumberFormatException ex) { p.sendMessage(color("&cInvalid amount.")); }
            }
            default -> p.sendMessage(color("&e/hrshop edit | addsection | editsection | delsection | additem | delitem | price | setmoney"));
        }
        return true;
    }

    private void showTop(CommandSender sender) {
        List<Map.Entry<UUID, Double>> top = new ArrayList<>(balances.entrySet());
        top.sort((x,y) -> Double.compare(y.getValue(), x.getValue()));
        sender.sendMessage(color("&6&lHR Shop &e- Top 10 Balances"));
        int rank = 1;
        for (var e : top) {
            if (rank > 10) break;
            OfflinePlayer op = Bukkit.getOfflinePlayer(e.getKey());
            sender.sendMessage(color("&e" + rank++ + ". &f" + (op.getName() == null ? "Unknown" : op.getName()) + " &7- &a" + money(e.getValue())));
        }
        if (top.isEmpty()) sender.sendMessage(color("&7No balances recorded yet."));
    }
    private void openMain(Player p) {
        Inventory inv = Bukkit.createInventory(null, 54, color(getConfig().getString("shop-title", "&8HR Shop")));
        int[] slots = {10,12,14,16,28,30,32,34}; int n=0;
        for (ShopSection s : sections.values()) {
            if (n >= slots.length) break;
            inv.setItem(slots[n++], named(icon(s.icon), "&b" + s.name, "&7Click to browse"));
        }
        inv.setItem(49, named(Material.GOLD_INGOT, "&6Your Balance", "&f" + money(balance(p.getUniqueId()))));
        p.openInventory(inv);
    }
    private void openSection(Player p, ShopSection s) {
        Inventory inv = Bukkit.createInventory(null, 54, color("&8Shop: " + s.name));
        int slot=0;
        for (ShopItem it : s.items.values()) { if (slot>=45) break; inv.setItem(slot++, display(it)); }
        inv.setItem(49, named(Material.ARROW, "&eBack to Sections"));
        p.openInventory(inv);
    }
    private void openEditor(Player p) {
        Inventory inv = Bukkit.createInventory(null, 54, color(getConfig().getString("editor-title", "&8HR Shop Editor")));
        int slot=0;
        for (ShopSection s : sections.values()) {
            if (slot>=45) break;
            inv.setItem(slot++, named(icon(s.icon), "&b"+s.name, "&7Left-click: open", "&cRight-click: delete"));
        }
        inv.setItem(45, named(Material.EMERALD, "&aAdd Section", "&7/hrshop addsection <id> <name>"));
        inv.setItem(46, named(Material.ANVIL, "&eAdd Item", "&7Hold item, then /hrshop additem <section> <buy> <sell>"));
        inv.setItem(47, named(Material.PAPER, "&fEdit Prices", "&7/hrshop price <section> <material> <buy> <sell>"));
        inv.setItem(49, named(Material.BARRIER, "&cClose"));
        p.openInventory(inv);
    }
    @EventHandler public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        String title = ChatColor.stripColor(e.getView().getTitle());
        if (title == null) return;
        if (title.equals(ChatColor.stripColor(color(getConfig().getString("shop-title", "&8HR Shop"))))) {
            e.setCancelled(true);
            if (e.getRawSlot() < 0 || e.getRawSlot() >= e.getInventory().getSize()) return;
            int[] slots={10,12,14,16,28,30,32,34}; int index=Arrays.binarySearch(slots,e.getRawSlot());
            if (index>=0 && index<sections.size()) openSection(p,new ArrayList<>(sections.values()).get(index));
        } else if (title.startsWith("Shop: ")) {
            e.setCancelled(true);
            if (e.getRawSlot()<0 || e.getRawSlot()>=e.getInventory().getSize()) return;
            if (e.getRawSlot()==49) { openMain(p); return; }
            ShopSection section=sections.get(title.substring(6).toLowerCase(Locale.ROOT));
            if (section==null) section=sections.values().stream().filter(s -> s.name.equalsIgnoreCase(title.substring(6))).findFirst().orElse(null);
            if (section==null) return;
            ItemStack clicked=e.getCurrentItem();
            if (clicked==null || clicked.getType().isAir()) return;
            ShopItem it=section.items.get(clicked.getType());
            if (it==null) return;
            if (e.isLeftClick()) buy(p,it,1);
            else if (e.isRightClick()) sell(p,it,1);
        } else if (title.equals(ChatColor.stripColor(color(getConfig().getString("editor-title", "&8HR Shop Editor"))))) {
            e.setCancelled(true);
            int raw=e.getRawSlot();
            if (raw<0 || raw>=e.getInventory().getSize()) return;
            if (raw==49) { p.closeInventory(); return; }
            if (raw<45) {
                int index=raw;
                if (index>=sections.size()) return;
                ShopSection s=new ArrayList<>(sections.values()).get(index);
                if (e.isRightClick()) { sections.remove(s.id); saveShop(); openEditor(p); }
                else openSection(p,s);
            }
            if (raw==45) p.sendMessage(color("&e/hrshop addsection <id> <name>"));
            if (raw==46) p.sendMessage(color("&eHold item: /hrshop additem <section> <buy> <sell>"));
            if (raw==47) p.sendMessage(color("&e/hrshop price <section> <material> <buy> <sell>"));
        }
    }
    @EventHandler public void onDrag(InventoryDragEvent e) {
        String t=ChatColor.stripColor(e.getView().getTitle());
        if (t!=null && (t.equals(ChatColor.stripColor(color(getConfig().getString("shop-title","&8HR Shop")))) || t.startsWith("Shop: ") || t.equals(ChatColor.stripColor(color(getConfig().getString("editor-title","&8HR Shop Editor")))))) e.setCancelled(true);
    }
    private void buy(Player p, ShopItem it, int amount) {
        if (it.buy < 0) { p.sendMessage(color("&cThis item cannot be bought.")); return; }
        double cost=it.buy*amount;
        if (balance(p.getUniqueId())<cost) { p.sendMessage(color("&cNot enough money.")); return; }
        if (p.getInventory().firstEmpty()<0) { p.sendMessage(color("&cYour inventory is full.")); return; }
        setBalance(p.getUniqueId(),balance(p.getUniqueId())-cost);
        p.getInventory().addItem(new ItemStack(it.material,amount));
        p.sendMessage(color("&aBought " + amount + "x " + pretty(it.material) + " for " + money(cost)));
    }
    private void sell(Player p, ShopItem it, int amount) {
        if (it.sell < 0) { p.sendMessage(color("&cThis item cannot be sold.")); return; }
        int found=0;
        for (ItemStack stack:p.getInventory().getStorageContents()) if (stack!=null && stack.getType()==it.material) found+=stack.getAmount();
        if (found<amount) { p.sendMessage(color("&cYou do not have enough items.")); return; }
        int left=amount;
        for (int i=0;i<p.getInventory().getStorageContents().length && left>0;i++) {
            ItemStack stack=p.getInventory().getItem(i);
            if (stack==null || stack.getType()!=it.material) continue;
            int take=Math.min(left,stack.getAmount()); stack.setAmount(stack.getAmount()-take); left-=take;
            if (stack.getAmount()<=0) p.getInventory().setItem(i,null);
        }
        double earned=it.sell*amount; setBalance(p.getUniqueId(),balance(p.getUniqueId())+earned);
        p.sendMessage(color("&aSold " + amount + "x " + pretty(it.material) + " for " + money(earned)));
    }
    private ItemStack display(ShopItem it) { return named(new ItemStack(it.material),"&f"+pretty(it.material),"&aBuy: "+(it.buy<0?"Disabled":money(it.buy)),"&cSell: "+(it.sell<0?"Disabled":money(it.sell)),"&7Left-click to buy","&7Right-click to sell"); }
    private ItemStack named(Material m,String name,String... lore) { return named(new ItemStack(m),name,lore); }
    private ItemStack named(ItemStack item,String name,String... lore) {
        ItemMeta meta=item.getItemMeta(); if(meta!=null){meta.setDisplayName(color(name)); List<String> l=new ArrayList<>(); for(String s:lore)l.add(color(s)); meta.setLore(l); item.setItemMeta(meta);} return item;
    }
    private Material icon(String name) { try{return Material.valueOf(name.toUpperCase(Locale.ROOT));}catch(Exception e){return Material.CHEST;} }
    private String money(double amount) { return currency+String.format(Locale.US,"%.2f",amount); }
    private String pretty(Material m) { String s=m.name().toLowerCase(Locale.ROOT).replace('_',' '); return Character.toUpperCase(s.charAt(0))+s.substring(1); }
    private String color(String s) { return ChatColor.translateAlternateColorCodes('&',s); }
    private static final class ShopSection {
        final String id; String name; final String icon; final Map<Material,ShopItem> items=new LinkedHashMap<>();
        ShopSection(String id,String name,String icon){this.id=id;this.name=name;this.icon=icon;}
    }
    private static final class ShopItem {
        final Material material; final double buy,sell;
        ShopItem(Material material,double buy,double sell){this.material=material;this.buy=buy;this.sell=sell;}
    }
}
